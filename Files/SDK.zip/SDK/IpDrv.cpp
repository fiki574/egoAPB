
struct IpDrv_StringToIpAddr_Parms
{
	struct FString                                     str;                                              		// 0x000000 (0x000C)              
	struct FIpAddr                                     Addr;                                             		// 0x00000C (0x0014)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000020 (0x0004) [0x00000001] 
};

bool AInternetLink::StringToIpAddr(struct FString str,struct FIpAddr* Addr)
{
	static UFieldFunc* pFnStringToIpAddr = NULL;
	if(!pFnStringToIpAddr)
		pFnStringToIpAddr = UObject::FindFunction("Function IpDrv.InternetLink.StringToIpAddr");

	IpDrv_StringToIpAddr_Parms StringToIpAddr_Parms;
	memcpy(&StringToIpAddr_Parms.str,&str,0xC);
	pFnStringToIpAddr->FunctionFlags |= ~0x400;
	ProcessEvent(pFnStringToIpAddr,NULL,&StringToIpAddr_Parms,NULL);
	pFnStringToIpAddr->FunctionFlags |= 0x400;
	if(Addr)
		memcpy(Addr,&StringToIpAddr_Parms.Addr,0x14);
	return StringToIpAddr_Parms.ReturnValue;
}

struct IpDrv_ResolveFailed_Parms
{
};

void AInternetLink::ResolveFailed()
{
	static UFieldFunc* pFnResolveFailed = NULL;
	if(!pFnResolveFailed)
		pFnResolveFailed = UObject::FindFunction("Function IpDrv.InternetLink.ResolveFailed");

	IpDrv_ResolveFailed_Parms ResolveFailed_Parms;
	ProcessEvent(pFnResolveFailed,NULL,&ResolveFailed_Parms,NULL);
}

struct IpDrv_Resolved_Parms
{
	struct FIpAddr                                     Addr;                                             		// 0x000000 (0x0014)              
};

void AInternetLink::Resolved(struct FIpAddr Addr)
{
	static UFieldFunc* pFnResolved = NULL;
	if(!pFnResolved)
		pFnResolved = UObject::FindFunction("Function IpDrv.InternetLink.Resolved");

	IpDrv_Resolved_Parms Resolved_Parms;
	memcpy(&Resolved_Parms.Addr,&Addr,0x14);
	ProcessEvent(pFnResolved,NULL,&Resolved_Parms,NULL);
}

struct IpDrv_GetLastError_Parms
{
	int                                                ReturnValue;                                      		// 0x000000 (0x0004)              
};

int AInternetLink::GetLastError()
{
	static UFieldFunc* pFnGetLastError = NULL;
	if(!pFnGetLastError)
		pFnGetLastError = UObject::FindFunction("Function IpDrv.InternetLink.GetLastError");

	IpDrv_GetLastError_Parms GetLastError_Parms;
	pFnGetLastError->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetLastError,NULL,&GetLastError_Parms,NULL);
	pFnGetLastError->FunctionFlags |= 0x400;
	return GetLastError_Parms.ReturnValue;
}

struct IpDrv_IsDataPending_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool AInternetLink::IsDataPending()
{
	static UFieldFunc* pFnIsDataPending = NULL;
	if(!pFnIsDataPending)
		pFnIsDataPending = UObject::FindFunction("Function IpDrv.InternetLink.IsDataPending");

	IpDrv_IsDataPending_Parms IsDataPending_Parms;
	pFnIsDataPending->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIsDataPending,NULL,&IsDataPending_Parms,NULL);
	pFnIsDataPending->FunctionFlags |= 0x400;
	return IsDataPending_Parms.ReturnValue;
}

struct IpDrv_Resolve_Parms
{
	struct FString                                     Domain;                                           		// 0x000000 (0x000C)              
};

void AInternetLink::Resolve(struct FString Domain)
{
	static UFieldFunc* pFnResolve = NULL;
	if(!pFnResolve)
		pFnResolve = UObject::FindFunction("Function IpDrv.InternetLink.Resolve");

	IpDrv_Resolve_Parms Resolve_Parms;
	memcpy(&Resolve_Parms.Domain,&Domain,0xC);
	pFnResolve->FunctionFlags |= ~0x400;
	ProcessEvent(pFnResolve,NULL,&Resolve_Parms,NULL);
	pFnResolve->FunctionFlags |= 0x400;
}

struct IpDrv_ParseURL_Parms
{
	struct FString                                     URL;                                              		// 0x000000 (0x000C)              
	struct FString                                     Addr;                                             		// 0x00000C (0x000C)              
	int                                                PortNum;                                          		// 0x000018 (0x0004)              
	struct FString                                     LevelName;                                        		// 0x00001C (0x000C)              
	struct FString                                     EntryName;                                        		// 0x000028 (0x000C)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000034 (0x0004) [0x00000001] 
};

bool AInternetLink::ParseURL(struct FString URL,struct FString* Addr,int* PortNum,struct FString* LevelName,struct FString* EntryName)
{
	static UFieldFunc* pFnParseURL = NULL;
	if(!pFnParseURL)
		pFnParseURL = UObject::FindFunction("Function IpDrv.InternetLink.ParseURL");

	IpDrv_ParseURL_Parms ParseURL_Parms;
	memcpy(&ParseURL_Parms.URL,&URL,0xC);
	pFnParseURL->FunctionFlags |= ~0x400;
	ProcessEvent(pFnParseURL,NULL,&ParseURL_Parms,NULL);
	pFnParseURL->FunctionFlags |= 0x400;
	if(Addr)
		memcpy(Addr,&ParseURL_Parms.Addr,0xC);
	if(PortNum)
		*PortNum = ParseURL_Parms.PortNum;
	if(LevelName)
		memcpy(LevelName,&ParseURL_Parms.LevelName,0xC);
	if(EntryName)
		memcpy(EntryName,&ParseURL_Parms.EntryName,0xC);
	return ParseURL_Parms.ReturnValue;
}

struct IpDrv_IpAddrToString_Parms
{
	struct FIpAddr                                     Arg;                                              		// 0x000000 (0x0014)              
	struct FString                                     ReturnValue;                                      		// 0x000014 (0x000C)              
};

struct FString AInternetLink::IpAddrToString(struct FIpAddr Arg)
{
	static UFieldFunc* pFnIpAddrToString = NULL;
	if(!pFnIpAddrToString)
		pFnIpAddrToString = UObject::FindFunction("Function IpDrv.InternetLink.IpAddrToString");

	IpDrv_IpAddrToString_Parms IpAddrToString_Parms;
	memcpy(&IpAddrToString_Parms.Arg,&Arg,0x14);
	pFnIpAddrToString->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIpAddrToString,NULL,&IpAddrToString_Parms,NULL);
	pFnIpAddrToString->FunctionFlags |= 0x400;
	return IpAddrToString_Parms.ReturnValue;
}

struct IpDrv_GetLocalIP_Parms
{
	struct FIpAddr                                     Arg;                                              		// 0x000000 (0x0014)              
};

void AInternetLink::GetLocalIP(struct FIpAddr* Arg)
{
	static UFieldFunc* pFnGetLocalIP = NULL;
	if(!pFnGetLocalIP)
		pFnGetLocalIP = UObject::FindFunction("Function IpDrv.InternetLink.GetLocalIP");

	IpDrv_GetLocalIP_Parms GetLocalIP_Parms;
	pFnGetLocalIP->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetLocalIP,NULL,&GetLocalIP_Parms,NULL);
	pFnGetLocalIP->FunctionFlags |= 0x400;
	if(Arg)
		memcpy(Arg,&GetLocalIP_Parms.Arg,0x14);
}

struct IpDrv_ReadBinary_Parms
{
	int                                                Count;                                            		// 0x000000 (0x0004)              
	unsigned char                                      B[0xFF];                                          		// 0x000004 (0x00FF)              
	unsigned char                                      _0x000103[0x1];                                   		// 0x000103 (0x0001) ALIGNEMENT
	int                                                ReturnValue;                                      		// 0x000104 (0x0004)              
};

int ATcpLink::ReadBinary(int Count,unsigned char* B)
{
	static UFieldFunc* pFnReadBinary = NULL;
	if(!pFnReadBinary)
		pFnReadBinary = UObject::FindFunction("Function IpDrv.TcpLink.ReadBinary");

	IpDrv_ReadBinary_Parms ReadBinary_Parms;
	ReadBinary_Parms.Count = Count;
	pFnReadBinary->FunctionFlags |= ~0x400;
	ProcessEvent(pFnReadBinary,NULL,&ReadBinary_Parms,NULL);
	pFnReadBinary->FunctionFlags |= 0x400;
	if(B)
		memcpy(B,&ReadBinary_Parms.B,0xFF);
	return ReadBinary_Parms.ReturnValue;
}

struct IpDrv_Closed_Parms
{
};

void ATcpLink::Closed()
{
	static UFieldFunc* pFnClosed = NULL;
	if(!pFnClosed)
		pFnClosed = UObject::FindFunction("Function IpDrv.TcpLink.Closed");

	IpDrv_Closed_Parms Closed_Parms;
	ProcessEvent(pFnClosed,NULL,&Closed_Parms,NULL);
}

struct IpDrv_IsConnected_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool ATcpLink::IsConnected()
{
	static UFieldFunc* pFnIsConnected = NULL;
	if(!pFnIsConnected)
		pFnIsConnected = UObject::FindFunction("Function IpDrv.TcpLink.IsConnected");

	IpDrv_IsConnected_Parms IsConnected_Parms;
	pFnIsConnected->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIsConnected,NULL,&IsConnected_Parms,NULL);
	pFnIsConnected->FunctionFlags |= 0x400;
	return IsConnected_Parms.ReturnValue;
}

struct IpDrv_Accepted_Parms
{
};

void ATcpLink::Accepted()
{
	static UFieldFunc* pFnAccepted = NULL;
	if(!pFnAccepted)
		pFnAccepted = UObject::FindFunction("Function IpDrv.TcpLink.Accepted");

	IpDrv_Accepted_Parms Accepted_Parms;
	ProcessEvent(pFnAccepted,NULL,&Accepted_Parms,NULL);
}

struct IpDrv_SendBinary_Parms
{
	int                                                Count;                                            		// 0x000000 (0x0004)              
	unsigned char                                      B[0xFF];                                          		// 0x000004 (0x00FF)              
	unsigned char                                      _0x000103[0x1];                                   		// 0x000103 (0x0001) ALIGNEMENT
	int                                                ReturnValue;                                      		// 0x000104 (0x0004)              
};

int ATcpLink::SendBinary(int Count,unsigned char* B)
{
	static UFieldFunc* pFnSendBinary = NULL;
	if(!pFnSendBinary)
		pFnSendBinary = UObject::FindFunction("Function IpDrv.TcpLink.SendBinary");

	IpDrv_SendBinary_Parms SendBinary_Parms;
	SendBinary_Parms.Count = Count;
	memcpy(&SendBinary_Parms.B,&B,0xFF);
	pFnSendBinary->FunctionFlags |= ~0x400;
	ProcessEvent(pFnSendBinary,NULL,&SendBinary_Parms,NULL);
	pFnSendBinary->FunctionFlags |= 0x400;
	return SendBinary_Parms.ReturnValue;
}

struct IpDrv_Opened_Parms
{
};

void ATcpLink::Opened()
{
	static UFieldFunc* pFnOpened = NULL;
	if(!pFnOpened)
		pFnOpened = UObject::FindFunction("Function IpDrv.TcpLink.Opened");

	IpDrv_Opened_Parms Opened_Parms;
	ProcessEvent(pFnOpened,NULL,&Opened_Parms,NULL);
}

struct IpDrv_ReceivedLine_Parms
{
	struct FString                                     Line;                                             		// 0x000000 (0x000C)              
};

void ATcpLink::ReceivedLine(struct FString Line)
{
	static UFieldFunc* pFnReceivedLine = NULL;
	if(!pFnReceivedLine)
		pFnReceivedLine = UObject::FindFunction("Function IpDrv.TcpLink.ReceivedLine");

	IpDrv_ReceivedLine_Parms ReceivedLine_Parms;
	memcpy(&ReceivedLine_Parms.Line,&Line,0xC);
	ProcessEvent(pFnReceivedLine,NULL,&ReceivedLine_Parms,NULL);
}

struct IpDrv_ReadText_Parms
{
	struct FString                                     str;                                              		// 0x000000 (0x000C)              
	int                                                ReturnValue;                                      		// 0x00000C (0x0004)              
};

int ATcpLink::ReadText(struct FString* str)
{
	static UFieldFunc* pFnReadText = NULL;
	if(!pFnReadText)
		pFnReadText = UObject::FindFunction("Function IpDrv.TcpLink.ReadText");

	IpDrv_ReadText_Parms ReadText_Parms;
	pFnReadText->FunctionFlags |= ~0x400;
	ProcessEvent(pFnReadText,NULL,&ReadText_Parms,NULL);
	pFnReadText->FunctionFlags |= 0x400;
	if(str)
		memcpy(str,&ReadText_Parms.str,0xC);
	return ReadText_Parms.ReturnValue;
}

struct IpDrv_Listen_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool ATcpLink::Listen()
{
	static UFieldFunc* pFnListen = NULL;
	if(!pFnListen)
		pFnListen = UObject::FindFunction("Function IpDrv.TcpLink.Listen");

	IpDrv_Listen_Parms Listen_Parms;
	pFnListen->FunctionFlags |= ~0x400;
	ProcessEvent(pFnListen,NULL,&Listen_Parms,NULL);
	pFnListen->FunctionFlags |= 0x400;
	return Listen_Parms.ReturnValue;
}

struct IpDrv_ReceivedBinary_Parms
{
	int                                                Count;                                            		// 0x000000 (0x0004)              
	unsigned char                                      B[0xFF];                                          		// 0x000004 (0x00FF)              
};

void ATcpLink::ReceivedBinary(int Count,unsigned char* B)
{
	static UFieldFunc* pFnReceivedBinary = NULL;
	if(!pFnReceivedBinary)
		pFnReceivedBinary = UObject::FindFunction("Function IpDrv.TcpLink.ReceivedBinary");

	IpDrv_ReceivedBinary_Parms ReceivedBinary_Parms;
	ReceivedBinary_Parms.Count = Count;
	memcpy(&ReceivedBinary_Parms.B,&B,0xFF);
	ProcessEvent(pFnReceivedBinary,NULL,&ReceivedBinary_Parms,NULL);
}

struct IpDrv_SendText_Parms
{
	struct FString                                     str;                                              		// 0x000000 (0x000C)              
	int                                                ReturnValue;                                      		// 0x00000C (0x0004)              
};

int ATcpLink::SendText(struct FString str)
{
	static UFieldFunc* pFnSendText = NULL;
	if(!pFnSendText)
		pFnSendText = UObject::FindFunction("Function IpDrv.TcpLink.SendText");

	IpDrv_SendText_Parms SendText_Parms;
	memcpy(&SendText_Parms.str,&str,0xC);
	pFnSendText->FunctionFlags |= ~0x400;
	ProcessEvent(pFnSendText,NULL,&SendText_Parms,NULL);
	pFnSendText->FunctionFlags |= 0x400;
	return SendText_Parms.ReturnValue;
}

struct IpDrv_Close_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool ATcpLink::Close()
{
	static UFieldFunc* pFnClose = NULL;
	if(!pFnClose)
		pFnClose = UObject::FindFunction("Function IpDrv.TcpLink.Close");

	IpDrv_Close_Parms Close_Parms;
	pFnClose->FunctionFlags |= ~0x400;
	ProcessEvent(pFnClose,NULL,&Close_Parms,NULL);
	pFnClose->FunctionFlags |= 0x400;
	return Close_Parms.ReturnValue;
}

struct IpDrv_BindPort_Parms
{
	int                                                PortNum;                                          		// 0x000000 (0x0004)              
	unsigned long                                      bUseNextAvailable : 1;                            		// 0x000004 (0x0004) [0x00000001] 
	int                                                ReturnValue;                                      		// 0x000008 (0x0004)              
};

int ATcpLink::BindPort(int PortNum,bool bUseNextAvailable)
{
	static UFieldFunc* pFnBindPort = NULL;
	if(!pFnBindPort)
		pFnBindPort = UObject::FindFunction("Function IpDrv.TcpLink.BindPort");

	IpDrv_BindPort_Parms BindPort_Parms;
	BindPort_Parms.PortNum = PortNum;
	BindPort_Parms.bUseNextAvailable = bUseNextAvailable;
	pFnBindPort->FunctionFlags |= ~0x400;
	ProcessEvent(pFnBindPort,NULL,&BindPort_Parms,NULL);
	pFnBindPort->FunctionFlags |= 0x400;
	return BindPort_Parms.ReturnValue;
}

struct IpDrv_Open_Parms
{
	struct FIpAddr                                     Addr;                                             		// 0x000000 (0x0014)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000014 (0x0004) [0x00000001] 
};

bool ATcpLink::Open(struct FIpAddr Addr)
{
	static UFieldFunc* pFnOpen = NULL;
	if(!pFnOpen)
		pFnOpen = UObject::FindFunction("Function IpDrv.TcpLink.Open");

	IpDrv_Open_Parms Open_Parms;
	memcpy(&Open_Parms.Addr,&Addr,0x14);
	pFnOpen->FunctionFlags |= ~0x400;
	ProcessEvent(pFnOpen,NULL,&Open_Parms,NULL);
	pFnOpen->FunctionFlags |= 0x400;
	return Open_Parms.ReturnValue;
}

struct IpDrv_ReceivedText_Parms
{
	struct FString                                     Text;                                             		// 0x000000 (0x000C)              
};

void ATcpLink::ReceivedText(struct FString Text)
{
	static UFieldFunc* pFnReceivedText = NULL;
	if(!pFnReceivedText)
		pFnReceivedText = UObject::FindFunction("Function IpDrv.TcpLink.ReceivedText");

	IpDrv_ReceivedText_Parms ReceivedText_Parms;
	memcpy(&ReceivedText_Parms.Text,&Text,0xC);
	ProcessEvent(pFnReceivedText,NULL,&ReceivedText_Parms,NULL);
}

struct IpDrv_IsPlayerInSession_Parms
{
	struct FName                                       SessionName;                                      		// 0x000000 (0x0008)              
	struct FUniqueNetId                                PlayerID;                                         		// 0x000008 (0x0008)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000010 (0x0004) [0x00000001] 
};

bool UOnlineSubsystemCommonImpl::IsPlayerInSession(struct FName SessionName,struct FUniqueNetId PlayerID)
{
	static UFieldFunc* pFnIsPlayerInSession = NULL;
	if(!pFnIsPlayerInSession)
		pFnIsPlayerInSession = UObject::FindFunction("Function IpDrv.OnlineSubsystemCommonImpl.IsPlayerInSession");

	IpDrv_IsPlayerInSession_Parms IsPlayerInSession_Parms;
	memcpy(&IsPlayerInSession_Parms.SessionName,&SessionName,0x8);
	memcpy(&IsPlayerInSession_Parms.PlayerID,&PlayerID,0x8);
	pFnIsPlayerInSession->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIsPlayerInSession,NULL,&IsPlayerInSession_Parms,NULL);
	pFnIsPlayerInSession->FunctionFlags |= 0x400;
	return IsPlayerInSession_Parms.ReturnValue;
}

struct IpDrv_GetPlayerNicknameFromIndex_Parms
{
	int                                                UserIndex;                                        		// 0x000000 (0x0004)              
	struct FString                                     ReturnValue;                                      		// 0x000004 (0x000C)              
};

struct FString UOnlineSubsystemCommonImpl::GetPlayerNicknameFromIndex(int UserIndex)
{
	static UFieldFunc* pFnGetPlayerNicknameFromIndex = NULL;
	if(!pFnGetPlayerNicknameFromIndex)
		pFnGetPlayerNicknameFromIndex = UObject::FindFunction("Function IpDrv.OnlineSubsystemCommonImpl.GetPlayerNicknameFromIndex");

	IpDrv_GetPlayerNicknameFromIndex_Parms GetPlayerNicknameFromIndex_Parms;
	GetPlayerNicknameFromIndex_Parms.UserIndex = UserIndex;
	ProcessEvent(pFnGetPlayerNicknameFromIndex,NULL,&GetPlayerNicknameFromIndex_Parms,NULL);
	return GetPlayerNicknameFromIndex_Parms.ReturnValue;
}

struct IpDrv_GetRegisteredPlayers_Parms
{
	struct FName                                       SessionName;                                      		// 0x000000 (0x0008)              
	TArray<struct FUniqueNetId>                        OutRegisteredPlayers;                             		// 0x000008 (0x000C)              
	//int                                                Idx;                                              		// 0x000014 (0x0004)              
	//int                                                PlayerIdx;                                        		// 0x000018 (0x0004)              
};

void UOnlineSubsystemCommonImpl::GetRegisteredPlayers(struct FName SessionName,TArray<struct FUniqueNetId>* OutRegisteredPlayers)
{
	static UFieldFunc* pFnGetRegisteredPlayers = NULL;
	if(!pFnGetRegisteredPlayers)
		pFnGetRegisteredPlayers = UObject::FindFunction("Function IpDrv.OnlineSubsystemCommonImpl.GetRegisteredPlayers");

	IpDrv_GetRegisteredPlayers_Parms GetRegisteredPlayers_Parms;
	memcpy(&GetRegisteredPlayers_Parms.SessionName,&SessionName,0x8);
	ProcessEvent(pFnGetRegisteredPlayers,NULL,&GetRegisteredPlayers_Parms,NULL);
	if(OutRegisteredPlayers)
		memcpy(OutRegisteredPlayers,&GetRegisteredPlayers_Parms.OutRegisteredPlayers,0xC);
}

struct IpDrv_ProcessHeaderString_Parms
{
	struct FString                                     S;                                                		// 0x000000 (0x000C)              
	//int                                                I;                                                		// 0x00000C (0x0004)              
};

void UWebRequest::ProcessHeaderString(struct FString S)
{
	static UFieldFunc* pFnProcessHeaderString = NULL;
	if(!pFnProcessHeaderString)
		pFnProcessHeaderString = UObject::FindFunction("Function IpDrv.WebRequest.ProcessHeaderString");

	IpDrv_ProcessHeaderString_Parms ProcessHeaderString_Parms;
	memcpy(&ProcessHeaderString_Parms.S,&S,0xC);
	ProcessEvent(pFnProcessHeaderString,NULL,&ProcessHeaderString_Parms,NULL);
}

struct IpDrv_GetVariables_Parms
{
	TArray<struct FString>                             varNames;                                         		// 0x000000 (0x000C)              
};

void UWebRequest::GetVariables(TArray<struct FString>* varNames)
{
	static UFieldFunc* pFnGetVariables = NULL;
	if(!pFnGetVariables)
		pFnGetVariables = UObject::FindFunction("Function IpDrv.WebRequest.GetVariables");

	IpDrv_GetVariables_Parms GetVariables_Parms;
	pFnGetVariables->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetVariables,NULL,&GetVariables_Parms,NULL);
	pFnGetVariables->FunctionFlags |= 0x400;
	if(varNames)
		memcpy(varNames,&GetVariables_Parms.varNames,0xC);
}

struct IpDrv_GetVariableNumber_Parms
{
	struct FString                                     VariableName;                                     		// 0x000000 (0x000C)              
	int                                                Number;                                           		// 0x00000C (0x0004)              
	struct FString                                     DefaultValue;                                     		// 0x000010 (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x00001C (0x000C)              
};

struct FString UWebRequest::GetVariableNumber(struct FString VariableName,int Number,struct FString DefaultValue)
{
	static UFieldFunc* pFnGetVariableNumber = NULL;
	if(!pFnGetVariableNumber)
		pFnGetVariableNumber = UObject::FindFunction("Function IpDrv.WebRequest.GetVariableNumber");

	IpDrv_GetVariableNumber_Parms GetVariableNumber_Parms;
	memcpy(&GetVariableNumber_Parms.VariableName,&VariableName,0xC);
	GetVariableNumber_Parms.Number = Number;
	memcpy(&GetVariableNumber_Parms.DefaultValue,&DefaultValue,0xC);
	pFnGetVariableNumber->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetVariableNumber,NULL,&GetVariableNumber_Parms,NULL);
	pFnGetVariableNumber->FunctionFlags |= 0x400;
	return GetVariableNumber_Parms.ReturnValue;
}

struct IpDrv_GetHexDigit_Parms
{
	struct FString                                     D;                                                		// 0x000000 (0x000C)              
	int                                                ReturnValue;                                      		// 0x00000C (0x0004)              
};

int UWebRequest::GetHexDigit(struct FString D)
{
	static UFieldFunc* pFnGetHexDigit = NULL;
	if(!pFnGetHexDigit)
		pFnGetHexDigit = UObject::FindFunction("Function IpDrv.WebRequest.GetHexDigit");

	IpDrv_GetHexDigit_Parms GetHexDigit_Parms;
	memcpy(&GetHexDigit_Parms.D,&D,0xC);
	ProcessEvent(pFnGetHexDigit,NULL,&GetHexDigit_Parms,NULL);
	return GetHexDigit_Parms.ReturnValue;
}

struct IpDrv_AddHeader_Parms
{
	struct FString                                     HeaderName;                                       		// 0x000000 (0x000C)              
	struct FString                                     Value;                                            		// 0x00000C (0x000C)              
};

void UWebRequest::AddHeader(struct FString HeaderName,struct FString Value)
{
	static UFieldFunc* pFnAddHeader = NULL;
	if(!pFnAddHeader)
		pFnAddHeader = UObject::FindFunction("Function IpDrv.WebRequest.AddHeader");

	IpDrv_AddHeader_Parms AddHeader_Parms;
	memcpy(&AddHeader_Parms.HeaderName,&HeaderName,0xC);
	memcpy(&AddHeader_Parms.Value,&Value,0xC);
	pFnAddHeader->FunctionFlags |= ~0x400;
	ProcessEvent(pFnAddHeader,NULL,&AddHeader_Parms,NULL);
	pFnAddHeader->FunctionFlags |= 0x400;
}

struct IpDrv_Dump_Parms
{
};

void UWebRequest::Dump()
{
	static UFieldFunc* pFnDump = NULL;
	if(!pFnDump)
		pFnDump = UObject::FindFunction("Function IpDrv.WebRequest.Dump");

	IpDrv_Dump_Parms Dump_Parms;
	pFnDump->FunctionFlags |= ~0x400;
	ProcessEvent(pFnDump,NULL,&Dump_Parms,NULL);
	pFnDump->FunctionFlags |= 0x400;
}

struct IpDrv_GetVariableCount_Parms
{
	struct FString                                     VariableName;                                     		// 0x000000 (0x000C)              
	int                                                ReturnValue;                                      		// 0x00000C (0x0004)              
};

int UWebRequest::GetVariableCount(struct FString VariableName)
{
	static UFieldFunc* pFnGetVariableCount = NULL;
	if(!pFnGetVariableCount)
		pFnGetVariableCount = UObject::FindFunction("Function IpDrv.WebRequest.GetVariableCount");

	IpDrv_GetVariableCount_Parms GetVariableCount_Parms;
	memcpy(&GetVariableCount_Parms.VariableName,&VariableName,0xC);
	pFnGetVariableCount->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetVariableCount,NULL,&GetVariableCount_Parms,NULL);
	pFnGetVariableCount->FunctionFlags |= 0x400;
	return GetVariableCount_Parms.ReturnValue;
}

struct IpDrv_DecodeFormData_Parms
{
	struct FString                                     Data;                                             		// 0x000000 (0x000C)              
	//struct FString                                     Token[0x2];                                       		// 0x00000C (0x0018)              
	//struct FString                                     ch;                                               		// 0x000024 (0x000C)              
	//int                                                I;                                                		// 0x000030 (0x0004)              
	//int                                                H1;                                               		// 0x000034 (0x0004)              
	//int                                                H2;                                               		// 0x000038 (0x0004)              
	//int                                                Limit;                                            		// 0x00003C (0x0004)              
	//int                                                T;                                                		// 0x000040 (0x0004)              
};

void UWebRequest::DecodeFormData(struct FString Data)
{
	static UFieldFunc* pFnDecodeFormData = NULL;
	if(!pFnDecodeFormData)
		pFnDecodeFormData = UObject::FindFunction("Function IpDrv.WebRequest.DecodeFormData");

	IpDrv_DecodeFormData_Parms DecodeFormData_Parms;
	memcpy(&DecodeFormData_Parms.Data,&Data,0xC);
	ProcessEvent(pFnDecodeFormData,NULL,&DecodeFormData_Parms,NULL);
}

struct IpDrv_GetVariable_Parms
{
	struct FString                                     VariableName;                                     		// 0x000000 (0x000C)              
	struct FString                                     DefaultValue;                                     		// 0x00000C (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x000018 (0x000C)              
};

struct FString UWebRequest::GetVariable(struct FString VariableName,struct FString DefaultValue)
{
	static UFieldFunc* pFnGetVariable = NULL;
	if(!pFnGetVariable)
		pFnGetVariable = UObject::FindFunction("Function IpDrv.WebRequest.GetVariable");

	IpDrv_GetVariable_Parms GetVariable_Parms;
	memcpy(&GetVariable_Parms.VariableName,&VariableName,0xC);
	memcpy(&GetVariable_Parms.DefaultValue,&DefaultValue,0xC);
	pFnGetVariable->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetVariable,NULL,&GetVariable_Parms,NULL);
	pFnGetVariable->FunctionFlags |= 0x400;
	return GetVariable_Parms.ReturnValue;
}

struct IpDrv_EncodeBase64_Parms
{
	struct FString                                     Decoded;                                          		// 0x000000 (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x00000C (0x000C)              
};

struct FString UWebRequest::EncodeBase64(struct FString Decoded)
{
	static UFieldFunc* pFnEncodeBase64 = NULL;
	if(!pFnEncodeBase64)
		pFnEncodeBase64 = UObject::FindFunction("Function IpDrv.WebRequest.EncodeBase64");

	IpDrv_EncodeBase64_Parms EncodeBase64_Parms;
	memcpy(&EncodeBase64_Parms.Decoded,&Decoded,0xC);
	pFnEncodeBase64->FunctionFlags |= ~0x400;
	ProcessEvent(pFnEncodeBase64,NULL,&EncodeBase64_Parms,NULL);
	pFnEncodeBase64->FunctionFlags |= 0x400;
	return EncodeBase64_Parms.ReturnValue;
}

struct IpDrv_GetHeader_Parms
{
	struct FString                                     HeaderName;                                       		// 0x000000 (0x000C)              
	struct FString                                     DefaultValue;                                     		// 0x00000C (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x000018 (0x000C)              
};

struct FString UWebRequest::GetHeader(struct FString HeaderName,struct FString DefaultValue)
{
	static UFieldFunc* pFnGetHeader = NULL;
	if(!pFnGetHeader)
		pFnGetHeader = UObject::FindFunction("Function IpDrv.WebRequest.GetHeader");

	IpDrv_GetHeader_Parms GetHeader_Parms;
	memcpy(&GetHeader_Parms.HeaderName,&HeaderName,0xC);
	memcpy(&GetHeader_Parms.DefaultValue,&DefaultValue,0xC);
	pFnGetHeader->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetHeader,NULL,&GetHeader_Parms,NULL);
	pFnGetHeader->FunctionFlags |= 0x400;
	return GetHeader_Parms.ReturnValue;
}

struct IpDrv_GetHeaders_Parms
{
	TArray<struct FString>                             Headers;                                          		// 0x000000 (0x000C)              
};

void UWebRequest::GetHeaders(TArray<struct FString>* Headers)
{
	static UFieldFunc* pFnGetHeaders = NULL;
	if(!pFnGetHeaders)
		pFnGetHeaders = UObject::FindFunction("Function IpDrv.WebRequest.GetHeaders");

	IpDrv_GetHeaders_Parms GetHeaders_Parms;
	pFnGetHeaders->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetHeaders,NULL,&GetHeaders_Parms,NULL);
	pFnGetHeaders->FunctionFlags |= 0x400;
	if(Headers)
		memcpy(Headers,&GetHeaders_Parms.Headers,0xC);
}

struct IpDrv_AddVariable_Parms
{
	struct FString                                     VariableName;                                     		// 0x000000 (0x000C)              
	struct FString                                     Value;                                            		// 0x00000C (0x000C)              
};

void UWebRequest::AddVariable(struct FString VariableName,struct FString Value)
{
	static UFieldFunc* pFnAddVariable = NULL;
	if(!pFnAddVariable)
		pFnAddVariable = UObject::FindFunction("Function IpDrv.WebRequest.AddVariable");

	IpDrv_AddVariable_Parms AddVariable_Parms;
	memcpy(&AddVariable_Parms.VariableName,&VariableName,0xC);
	memcpy(&AddVariable_Parms.Value,&Value,0xC);
	pFnAddVariable->FunctionFlags |= ~0x400;
	ProcessEvent(pFnAddVariable,NULL,&AddVariable_Parms,NULL);
	pFnAddVariable->FunctionFlags |= 0x400;
}

struct IpDrv_DecodeBase64_Parms
{
	struct FString                                     Encoded;                                          		// 0x000000 (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x00000C (0x000C)              
};

struct FString UWebRequest::DecodeBase64(struct FString Encoded)
{
	static UFieldFunc* pFnDecodeBase64 = NULL;
	if(!pFnDecodeBase64)
		pFnDecodeBase64 = UObject::FindFunction("Function IpDrv.WebRequest.DecodeBase64");

	IpDrv_DecodeBase64_Parms DecodeBase64_Parms;
	memcpy(&DecodeBase64_Parms.Encoded,&Encoded,0xC);
	pFnDecodeBase64->FunctionFlags |= ~0x400;
	ProcessEvent(pFnDecodeBase64,NULL,&DecodeBase64_Parms,NULL);
	pFnDecodeBase64->FunctionFlags |= 0x400;
	return DecodeBase64_Parms.ReturnValue;
}

struct IpDrv_ClearSubst_Parms
{
};

void UWebResponse::ClearSubst()
{
	static UFieldFunc* pFnClearSubst = NULL;
	if(!pFnClearSubst)
		pFnClearSubst = UObject::FindFunction("Function IpDrv.WebResponse.ClearSubst");

	IpDrv_ClearSubst_Parms ClearSubst_Parms;
	pFnClearSubst->FunctionFlags |= ~0x400;
	ProcessEvent(pFnClearSubst,NULL,&ClearSubst_Parms,NULL);
	pFnClearSubst->FunctionFlags |= 0x400;
}

struct IpDrv_Redirect_Parms
{
	struct FString                                     URL;                                              		// 0x000000 (0x000C)              
};

void UWebResponse::Redirect(struct FString URL)
{
	static UFieldFunc* pFnRedirect = NULL;
	if(!pFnRedirect)
		pFnRedirect = UObject::FindFunction("Function IpDrv.WebResponse.Redirect");

	IpDrv_Redirect_Parms Redirect_Parms;
	memcpy(&Redirect_Parms.URL,&URL,0xC);
	ProcessEvent(pFnRedirect,NULL,&Redirect_Parms,NULL);
}

struct IpDrv_SendCachedFile_Parms
{
	struct FString                                     Filename;                                         		// 0x000000 (0x000C)              
	struct FString                                     ContentType;                                      		// 0x00000C (0x000C)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000018 (0x0004) [0x00000001] 
};

bool UWebResponse::SendCachedFile(struct FString Filename,struct FString ContentType)
{
	static UFieldFunc* pFnSendCachedFile = NULL;
	if(!pFnSendCachedFile)
		pFnSendCachedFile = UObject::FindFunction("Function IpDrv.WebResponse.SendCachedFile");

	IpDrv_SendCachedFile_Parms SendCachedFile_Parms;
	memcpy(&SendCachedFile_Parms.Filename,&Filename,0xC);
	memcpy(&SendCachedFile_Parms.ContentType,&ContentType,0xC);
	ProcessEvent(pFnSendCachedFile,NULL,&SendCachedFile_Parms,NULL);
	return SendCachedFile_Parms.ReturnValue;
}

struct IpDrv_SentText_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool UWebResponse::SentText()
{
	static UFieldFunc* pFnSentText = NULL;
	if(!pFnSentText)
		pFnSentText = UObject::FindFunction("Function IpDrv.WebResponse.SentText");

	IpDrv_SentText_Parms SentText_Parms;
	ProcessEvent(pFnSentText,NULL,&SentText_Parms,NULL);
	return SentText_Parms.ReturnValue;
}

struct IpDrv_IncludeBinaryFile_Parms
{
	struct FString                                     Filename;                                         		// 0x000000 (0x000C)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x00000C (0x0004) [0x00000001] 
};

bool UWebResponse::IncludeBinaryFile(struct FString Filename)
{
	static UFieldFunc* pFnIncludeBinaryFile = NULL;
	if(!pFnIncludeBinaryFile)
		pFnIncludeBinaryFile = UObject::FindFunction("Function IpDrv.WebResponse.IncludeBinaryFile");

	IpDrv_IncludeBinaryFile_Parms IncludeBinaryFile_Parms;
	memcpy(&IncludeBinaryFile_Parms.Filename,&Filename,0xC);
	pFnIncludeBinaryFile->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIncludeBinaryFile,NULL,&IncludeBinaryFile_Parms,NULL);
	pFnIncludeBinaryFile->FunctionFlags |= 0x400;
	return IncludeBinaryFile_Parms.ReturnValue;
}

struct IpDrv_FileExists_Parms
{
	struct FString                                     Filename;                                         		// 0x000000 (0x000C)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x00000C (0x0004) [0x00000001] 
};

bool UWebResponse::FileExists(struct FString Filename)
{
	static UFieldFunc* pFnFileExists = NULL;
	if(!pFnFileExists)
		pFnFileExists = UObject::FindFunction("Function IpDrv.WebResponse.FileExists");

	IpDrv_FileExists_Parms FileExists_Parms;
	memcpy(&FileExists_Parms.Filename,&Filename,0xC);
	pFnFileExists->FunctionFlags |= ~0x400;
	ProcessEvent(pFnFileExists,NULL,&FileExists_Parms,NULL);
	pFnFileExists->FunctionFlags |= 0x400;
	return FileExists_Parms.ReturnValue;
}

struct IpDrv_IncludeUHTM_Parms
{
	struct FString                                     Filename;                                         		// 0x000000 (0x000C)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x00000C (0x0004) [0x00000001] 
};

bool UWebResponse::IncludeUHTM(struct FString Filename)
{
	static UFieldFunc* pFnIncludeUHTM = NULL;
	if(!pFnIncludeUHTM)
		pFnIncludeUHTM = UObject::FindFunction("Function IpDrv.WebResponse.IncludeUHTM");

	IpDrv_IncludeUHTM_Parms IncludeUHTM_Parms;
	memcpy(&IncludeUHTM_Parms.Filename,&Filename,0xC);
	pFnIncludeUHTM->FunctionFlags |= ~0x400;
	ProcessEvent(pFnIncludeUHTM,NULL,&IncludeUHTM_Parms,NULL);
	pFnIncludeUHTM->FunctionFlags |= 0x400;
	return IncludeUHTM_Parms.ReturnValue;
}

struct IpDrv_LoadParsedUHTM_Parms
{
	struct FString                                     Filename;                                         		// 0x000000 (0x000C)              
	struct FString                                     ReturnValue;                                      		// 0x00000C (0x000C)              
};

struct FString UWebResponse::LoadParsedUHTM(struct FString Filename)
{
	static UFieldFunc* pFnLoadParsedUHTM = NULL;
	if(!pFnLoadParsedUHTM)
		pFnLoadParsedUHTM = UObject::FindFunction("Function IpDrv.WebResponse.LoadParsedUHTM");

	IpDrv_LoadParsedUHTM_Parms LoadParsedUHTM_Parms;
	memcpy(&LoadParsedUHTM_Parms.Filename,&Filename,0xC);
	pFnLoadParsedUHTM->FunctionFlags |= ~0x400;
	ProcessEvent(pFnLoadParsedUHTM,NULL,&LoadParsedUHTM_Parms,NULL);
	pFnLoadParsedUHTM->FunctionFlags |= 0x400;
	return LoadParsedUHTM_Parms.ReturnValue;
}

struct IpDrv_HTTPError_Parms
{
	int                                                ErrorNum;                                         		// 0x000000 (0x0004)              
	struct FString                                     Data;                                             		// 0x000004 (0x000C)              
};

void UWebResponse::HTTPError(int ErrorNum,struct FString Data)
{
	static UFieldFunc* pFnHTTPError = NULL;
	if(!pFnHTTPError)
		pFnHTTPError = UObject::FindFunction("Function IpDrv.WebResponse.HTTPError");

	IpDrv_HTTPError_Parms HTTPError_Parms;
	HTTPError_Parms.ErrorNum = ErrorNum;
	memcpy(&HTTPError_Parms.Data,&Data,0xC);
	ProcessEvent(pFnHTTPError,NULL,&HTTPError_Parms,NULL);
}

struct IpDrv_Dump_Parms
{
};

void UWebResponse::Dump()
{
	static UFieldFunc* pFnDump = NULL;
	if(!pFnDump)
		pFnDump = UObject::FindFunction("Function IpDrv.WebResponse.Dump");

	IpDrv_Dump_Parms Dump_Parms;
	pFnDump->FunctionFlags |= ~0x400;
	ProcessEvent(pFnDump,NULL,&Dump_Parms,NULL);
	pFnDump->FunctionFlags |= 0x400;
}

struct IpDrv_HTTPHeader_Parms
{
	struct FString                                     Header;                                           		// 0x000000 (0x000C)              
};

void UWebResponse::HTTPHeader(struct FString Header)
{
	static UFieldFunc* pFnHTTPHeader = NULL;
	if(!pFnHTTPHeader)
		pFnHTTPHeader = UObject::FindFunction("Function IpDrv.WebResponse.HTTPHeader");

	IpDrv_HTTPHeader_Parms HTTPHeader_Parms;
	memcpy(&HTTPHeader_Parms.Header,&Header,0xC);
	ProcessEvent(pFnHTTPHeader,NULL,&HTTPHeader_Parms,NULL);
}

struct IpDrv_Subst_Parms
{
	struct FString                                     Variable;                                         		// 0x000000 (0x000C)              
	struct FString                                     Value;                                            		// 0x00000C (0x000C)              
	unsigned long                                      bClear : 1;                                       		// 0x000018 (0x0004) [0x00000001] 
};

void UWebResponse::Subst(struct FString Variable,struct FString Value,bool bClear)
{
	static UFieldFunc* pFnSubst = NULL;
	if(!pFnSubst)
		pFnSubst = UObject::FindFunction("Function IpDrv.WebResponse.Subst");

	IpDrv_Subst_Parms Subst_Parms;
	memcpy(&Subst_Parms.Variable,&Variable,0xC);
	memcpy(&Subst_Parms.Value,&Value,0xC);
	Subst_Parms.bClear = bClear;
	pFnSubst->FunctionFlags |= ~0x400;
	ProcessEvent(pFnSubst,NULL,&Subst_Parms,NULL);
	pFnSubst->FunctionFlags |= 0x400;
}

struct IpDrv_HTTPResponse_Parms
{
	struct FString                                     Header;                                           		// 0x000000 (0x000C)              
};

void UWebResponse::HTTPResponse(struct FString Header)
{
	static UFieldFunc* pFnHTTPResponse = NULL;
	if(!pFnHTTPResponse)
		pFnHTTPResponse = UObject::FindFunction("Function IpDrv.WebResponse.HTTPResponse");

	IpDrv_HTTPResponse_Parms HTTPResponse_Parms;
	memcpy(&HTTPResponse_Parms.Header,&Header,0xC);
	ProcessEvent(pFnHTTPResponse,NULL,&HTTPResponse_Parms,NULL);
}

struct IpDrv_AddHeader_Parms
{
	struct FString                                     Header;                                           		// 0x000000 (0x000C)              
	unsigned long                                      bReplace : 1;                                     		// 0x00000C (0x0004) [0x00000001] 
	//int                                                I;                                                		// 0x000010 (0x0004)              
	//int                                                Idx;                                              		// 0x000014 (0x0004)              
	//struct FString                                     part;                                             		// 0x000018 (0x000C)              
	//struct FString                                     Entry;                                            		// 0x000024 (0x000C)              
};

void UWebResponse::AddHeader(struct FString Header,bool bReplace)
{
	static UFieldFunc* pFnAddHeader = NULL;
	if(!pFnAddHeader)
		pFnAddHeader = UObject::FindFunction("Function IpDrv.WebResponse.AddHeader");

	IpDrv_AddHeader_Parms AddHeader_Parms;
	memcpy(&AddHeader_Parms.Header,&Header,0xC);
	AddHeader_Parms.bReplace = bReplace;
	ProcessEvent(pFnAddHeader,NULL,&AddHeader_Parms,NULL);
}

struct IpDrv_SendHeaders_Parms
{
	//struct FString                                     hdr;                                              		// 0x000000 (0x000C)              
};

void UWebResponse::SendHeaders()
{
	static UFieldFunc* pFnSendHeaders = NULL;
	if(!pFnSendHeaders)
		pFnSendHeaders = UObject::FindFunction("Function IpDrv.WebResponse.SendHeaders");

	IpDrv_SendHeaders_Parms SendHeaders_Parms;
	ProcessEvent(pFnSendHeaders,NULL,&SendHeaders_Parms,NULL);
}

struct IpDrv_SendStandardHeaders_Parms
{
	struct FString                                     ContentType;                                      		// 0x000000 (0x000C)              
	unsigned long                                      bCache : 1;                                       		// 0x00000C (0x0004) [0x00000001] 
};

void UWebResponse::SendStandardHeaders(struct FString ContentType,bool bCache)
{
	static UFieldFunc* pFnSendStandardHeaders = NULL;
	if(!pFnSendStandardHeaders)
		pFnSendStandardHeaders = UObject::FindFunction("Function IpDrv.WebResponse.SendStandardHeaders");

	IpDrv_SendStandardHeaders_Parms SendStandardHeaders_Parms;
	memcpy(&SendStandardHeaders_Parms.ContentType,&ContentType,0xC);
	SendStandardHeaders_Parms.bCache = bCache;
	ProcessEvent(pFnSendStandardHeaders,NULL,&SendStandardHeaders_Parms,NULL);
}

struct IpDrv_SentResponse_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool UWebResponse::SentResponse()
{
	static UFieldFunc* pFnSentResponse = NULL;
	if(!pFnSentResponse)
		pFnSentResponse = UObject::FindFunction("Function IpDrv.WebResponse.SentResponse");

	IpDrv_SentResponse_Parms SentResponse_Parms;
	ProcessEvent(pFnSentResponse,NULL,&SentResponse_Parms,NULL);
	return SentResponse_Parms.ReturnValue;
}

struct IpDrv_SendBinary_Parms
{
	int                                                Count;                                            		// 0x000000 (0x0004)              
	unsigned char                                      B[0xFF];                                          		// 0x000004 (0x00FF)              
};

void UWebResponse::SendBinary(int Count,unsigned char* B)
{
	static UFieldFunc* pFnSendBinary = NULL;
	if(!pFnSendBinary)
		pFnSendBinary = UObject::FindFunction("Function IpDrv.WebResponse.SendBinary");

	IpDrv_SendBinary_Parms SendBinary_Parms;
	SendBinary_Parms.Count = Count;
	memcpy(&SendBinary_Parms.B,&B,0xFF);
	ProcessEvent(pFnSendBinary,NULL,&SendBinary_Parms,NULL);
}

struct IpDrv_GetHTTPExpiration_Parms
{
	int                                                OffsetSeconds;                                    		// 0x000000 (0x0004)              
	struct FString                                     ReturnValue;                                      		// 0x000004 (0x000C)              
};

struct FString UWebResponse::GetHTTPExpiration(int OffsetSeconds)
{
	static UFieldFunc* pFnGetHTTPExpiration = NULL;
	if(!pFnGetHTTPExpiration)
		pFnGetHTTPExpiration = UObject::FindFunction("Function IpDrv.WebResponse.GetHTTPExpiration");

	IpDrv_GetHTTPExpiration_Parms GetHTTPExpiration_Parms;
	GetHTTPExpiration_Parms.OffsetSeconds = OffsetSeconds;
	pFnGetHTTPExpiration->FunctionFlags |= ~0x400;
	ProcessEvent(pFnGetHTTPExpiration,NULL,&GetHTTPExpiration_Parms,NULL);
	pFnGetHTTPExpiration->FunctionFlags |= 0x400;
	return GetHTTPExpiration_Parms.ReturnValue;
}

struct IpDrv_SendText_Parms
{
	struct FString                                     Text;                                             		// 0x000000 (0x000C)              
	unsigned long                                      bNoCRLF : 1;                                      		// 0x00000C (0x0004) [0x00000001] 
};

void UWebResponse::SendText(struct FString Text,bool bNoCRLF)
{
	static UFieldFunc* pFnSendText = NULL;
	if(!pFnSendText)
		pFnSendText = UObject::FindFunction("Function IpDrv.WebResponse.SendText");

	IpDrv_SendText_Parms SendText_Parms;
	memcpy(&SendText_Parms.Text,&Text,0xC);
	SendText_Parms.bNoCRLF = bNoCRLF;
	ProcessEvent(pFnSendText,NULL,&SendText_Parms,NULL);
}

struct IpDrv_FailAuthentication_Parms
{
	struct FString                                     Realm;                                            		// 0x000000 (0x000C)              
};

void UWebResponse::FailAuthentication(struct FString Realm)
{
	static UFieldFunc* pFnFailAuthentication = NULL;
	if(!pFnFailAuthentication)
		pFnFailAuthentication = UObject::FindFunction("Function IpDrv.WebResponse.FailAuthentication");

	IpDrv_FailAuthentication_Parms FailAuthentication_Parms;
	memcpy(&FailAuthentication_Parms.Realm,&Realm,0xC);
	ProcessEvent(pFnFailAuthentication,NULL,&FailAuthentication_Parms,NULL);
}

struct IpDrv_Init_Parms
{
};

void UHelloWeb::Init()
{
	static UFieldFunc* pFnInit = NULL;
	if(!pFnInit)
		pFnInit = UObject::FindFunction("Function IpDrv.HelloWeb.Init");

	IpDrv_Init_Parms Init_Parms;
	ProcessEvent(pFnInit,NULL,&Init_Parms,NULL);
}

struct IpDrv_Query_Parms
{
	class UWebRequest*                                 Request;                                          		// 0x000000 (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x000004 (0x0004)              
	//int                                                I;                                                		// 0x000008 (0x0004)              
};

void UHelloWeb::Query(class UWebRequest* Request,class UWebResponse* Response)
{
	static UFieldFunc* pFnQuery = NULL;
	if(!pFnQuery)
		pFnQuery = UObject::FindFunction("Function IpDrv.HelloWeb.Query");

	IpDrv_Query_Parms Query_Parms;
	Query_Parms.Request = Request;
	Query_Parms.Response = Response;
	ProcessEvent(pFnQuery,NULL,&Query_Parms,NULL);
}

struct IpDrv_CleanupApp_Parms
{
};

void UWebApplication::CleanupApp()
{
	static UFieldFunc* pFnCleanupApp = NULL;
	if(!pFnCleanupApp)
		pFnCleanupApp = UObject::FindFunction("Function IpDrv.WebApplication.CleanupApp");

	IpDrv_CleanupApp_Parms CleanupApp_Parms;
	ProcessEvent(pFnCleanupApp,NULL,&CleanupApp_Parms,NULL);
}

struct IpDrv_PreQuery_Parms
{
	class UWebRequest*                                 Request;                                          		// 0x000000 (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x000004 (0x0004)              
	unsigned long                                      ReturnValue : 1;                                  		// 0x000008 (0x0004) [0x00000001] 
};

bool UWebApplication::PreQuery(class UWebRequest* Request,class UWebResponse* Response)
{
	static UFieldFunc* pFnPreQuery = NULL;
	if(!pFnPreQuery)
		pFnPreQuery = UObject::FindFunction("Function IpDrv.WebApplication.PreQuery");

	IpDrv_PreQuery_Parms PreQuery_Parms;
	PreQuery_Parms.Request = Request;
	PreQuery_Parms.Response = Response;
	ProcessEvent(pFnPreQuery,NULL,&PreQuery_Parms,NULL);
	return PreQuery_Parms.ReturnValue;
}

struct IpDrv_Init_Parms
{
};

void UWebApplication::Init()
{
	static UFieldFunc* pFnInit = NULL;
	if(!pFnInit)
		pFnInit = UObject::FindFunction("Function IpDrv.WebApplication.Init");

	IpDrv_Init_Parms Init_Parms;
	ProcessEvent(pFnInit,NULL,&Init_Parms,NULL);
}

struct IpDrv_Cleanup_Parms
{
};

void UWebApplication::Cleanup()
{
	static UFieldFunc* pFnCleanup = NULL;
	if(!pFnCleanup)
		pFnCleanup = UObject::FindFunction("Function IpDrv.WebApplication.Cleanup");

	IpDrv_Cleanup_Parms Cleanup_Parms;
	ProcessEvent(pFnCleanup,NULL,&Cleanup_Parms,NULL);
}

struct IpDrv_PostQuery_Parms
{
	class UWebRequest*                                 Request;                                          		// 0x000000 (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x000004 (0x0004)              
};

void UWebApplication::PostQuery(class UWebRequest* Request,class UWebResponse* Response)
{
	static UFieldFunc* pFnPostQuery = NULL;
	if(!pFnPostQuery)
		pFnPostQuery = UObject::FindFunction("Function IpDrv.WebApplication.PostQuery");

	IpDrv_PostQuery_Parms PostQuery_Parms;
	PostQuery_Parms.Request = Request;
	PostQuery_Parms.Response = Response;
	ProcessEvent(pFnPostQuery,NULL,&PostQuery_Parms,NULL);
}

struct IpDrv_Query_Parms
{
	class UWebRequest*                                 Request;                                          		// 0x000000 (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x000004 (0x0004)              
};

void UWebApplication::Query(class UWebRequest* Request,class UWebResponse* Response)
{
	static UFieldFunc* pFnQuery = NULL;
	if(!pFnQuery)
		pFnQuery = UObject::FindFunction("Function IpDrv.WebApplication.Query");

	IpDrv_Query_Parms Query_Parms;
	Query_Parms.Request = Request;
	Query_Parms.Response = Response;
	ProcessEvent(pFnQuery,NULL,&Query_Parms,NULL);
}

struct IpDrv_Query_Parms
{
	class UWebRequest*                                 Request;                                          		// 0x000000 (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x000004 (0x0004)              
	//struct FString                                     Image;                                            		// 0x000008 (0x000C)              
};

void UImageServer::Query(class UWebRequest* Request,class UWebResponse* Response)
{
	static UFieldFunc* pFnQuery = NULL;
	if(!pFnQuery)
		pFnQuery = UObject::FindFunction("Function IpDrv.ImageServer.Query");

	IpDrv_Query_Parms Query_Parms;
	Query_Parms.Request = Request;
	Query_Parms.Response = Response;
	ProcessEvent(pFnQuery,NULL,&Query_Parms,NULL);
}

struct IpDrv_CreateResponseObject_Parms
{
	//int                                                I;                                                		// 0x000000 (0x0004)              
};

void AWebConnection::CreateResponseObject()
{
	static UFieldFunc* pFnCreateResponseObject = NULL;
	if(!pFnCreateResponseObject)
		pFnCreateResponseObject = UObject::FindFunction("Function IpDrv.WebConnection.CreateResponseObject");

	IpDrv_CreateResponseObject_Parms CreateResponseObject_Parms;
	ProcessEvent(pFnCreateResponseObject,NULL,&CreateResponseObject_Parms,NULL);
}

struct IpDrv_Accepted_Parms
{
};

void AWebConnection::Accepted()
{
	static UFieldFunc* pFnAccepted = NULL;
	if(!pFnAccepted)
		pFnAccepted = UObject::FindFunction("Function IpDrv.WebConnection.Accepted");

	IpDrv_Accepted_Parms Accepted_Parms;
	ProcessEvent(pFnAccepted,NULL,&Accepted_Parms,NULL);
}

struct IpDrv_EndOfHeaders_Parms
{
};

void AWebConnection::EndOfHeaders()
{
	static UFieldFunc* pFnEndOfHeaders = NULL;
	if(!pFnEndOfHeaders)
		pFnEndOfHeaders = UObject::FindFunction("Function IpDrv.WebConnection.EndOfHeaders");

	IpDrv_EndOfHeaders_Parms EndOfHeaders_Parms;
	ProcessEvent(pFnEndOfHeaders,NULL,&EndOfHeaders_Parms,NULL);
}

struct IpDrv_Timer_Parms
{
};

void AWebConnection::Timer()
{
	static UFieldFunc* pFnTimer = NULL;
	if(!pFnTimer)
		pFnTimer = UObject::FindFunction("Function IpDrv.WebConnection.Timer");

	IpDrv_Timer_Parms Timer_Parms;
	ProcessEvent(pFnTimer,NULL,&Timer_Parms,NULL);
}

struct IpDrv_ReceivedText_Parms
{
	struct FString                                     Text;                                             		// 0x000000 (0x000C)              
	//int                                                I;                                                		// 0x00000C (0x0004)              
	//struct FString                                     S;                                                		// 0x000010 (0x000C)              
};

void AWebConnection::ReceivedText(struct FString Text)
{
	static UFieldFunc* pFnReceivedText = NULL;
	if(!pFnReceivedText)
		pFnReceivedText = UObject::FindFunction("Function IpDrv.WebConnection.ReceivedText");

	IpDrv_ReceivedText_Parms ReceivedText_Parms;
	memcpy(&ReceivedText_Parms.Text,&Text,0xC);
	ProcessEvent(pFnReceivedText,NULL,&ReceivedText_Parms,NULL);
}

struct IpDrv_CheckRawBytes_Parms
{
};

void AWebConnection::CheckRawBytes()
{
	static UFieldFunc* pFnCheckRawBytes = NULL;
	if(!pFnCheckRawBytes)
		pFnCheckRawBytes = UObject::FindFunction("Function IpDrv.WebConnection.CheckRawBytes");

	IpDrv_CheckRawBytes_Parms CheckRawBytes_Parms;
	ProcessEvent(pFnCheckRawBytes,NULL,&CheckRawBytes_Parms,NULL);
}

struct IpDrv_ProcessPost_Parms
{
	struct FString                                     S;                                                		// 0x000000 (0x000C)              
	//int                                                I;                                                		// 0x00000C (0x0004)              
};

void AWebConnection::ProcessPost(struct FString S)
{
	static UFieldFunc* pFnProcessPost = NULL;
	if(!pFnProcessPost)
		pFnProcessPost = UObject::FindFunction("Function IpDrv.WebConnection.ProcessPost");

	IpDrv_ProcessPost_Parms ProcessPost_Parms;
	memcpy(&ProcessPost_Parms.S,&S,0xC);
	ProcessEvent(pFnProcessPost,NULL,&ProcessPost_Parms,NULL);
}

struct IpDrv_IsHanging_Parms
{
	unsigned long                                      ReturnValue : 1;                                  		// 0x000000 (0x0004) [0x00000001] 
};

bool AWebConnection::IsHanging()
{
	static UFieldFunc* pFnIsHanging = NULL;
	if(!pFnIsHanging)
		pFnIsHanging = UObject::FindFunction("Function IpDrv.WebConnection.IsHanging");

	IpDrv_IsHanging_Parms IsHanging_Parms;
	ProcessEvent(pFnIsHanging,NULL,&IsHanging_Parms,NULL);
	return IsHanging_Parms.ReturnValue;
}

struct IpDrv_Cleanup_Parms
{
};

void AWebConnection::Cleanup()
{
	static UFieldFunc* pFnCleanup = NULL;
	if(!pFnCleanup)
		pFnCleanup = UObject::FindFunction("Function IpDrv.WebConnection.Cleanup");

	IpDrv_Cleanup_Parms Cleanup_Parms;
	ProcessEvent(pFnCleanup,NULL,&Cleanup_Parms,NULL);
}

struct IpDrv_ReceivedLine_Parms
{
	struct FString                                     S;                                                		// 0x000000 (0x000C)              
};

void AWebConnection::ReceivedLine(struct FString S)
{
	static UFieldFunc* pFnReceivedLine = NULL;
	if(!pFnReceivedLine)
		pFnReceivedLine = UObject::FindFunction("Function IpDrv.WebConnection.ReceivedLine");

	IpDrv_ReceivedLine_Parms ReceivedLine_Parms;
	memcpy(&ReceivedLine_Parms.S,&S,0xC);
	ProcessEvent(pFnReceivedLine,NULL,&ReceivedLine_Parms,NULL);
}

struct IpDrv_Closed_Parms
{
};

void AWebConnection::Closed()
{
	static UFieldFunc* pFnClosed = NULL;
	if(!pFnClosed)
		pFnClosed = UObject::FindFunction("Function IpDrv.WebConnection.Closed");

	IpDrv_Closed_Parms Closed_Parms;
	ProcessEvent(pFnClosed,NULL,&Closed_Parms,NULL);
}

struct IpDrv_ProcessHead_Parms
{
	struct FString                                     S;                                                		// 0x000000 (0x000C)              
};

void AWebConnection::ProcessHead(struct FString S)
{
	static UFieldFunc* pFnProcessHead = NULL;
	if(!pFnProcessHead)
		pFnProcessHead = UObject::FindFunction("Function IpDrv.WebConnection.ProcessHead");

	IpDrv_ProcessHead_Parms ProcessHead_Parms;
	memcpy(&ProcessHead_Parms.S,&S,0xC);
	ProcessEvent(pFnProcessHead,NULL,&ProcessHead_Parms,NULL);
}

struct IpDrv_ProcessGet_Parms
{
	struct FString                                     S;                                                		// 0x000000 (0x000C)              
	//int                                                I;                                                		// 0x00000C (0x0004)              
};

void AWebConnection::ProcessGet(struct FString S)
{
	static UFieldFunc* pFnProcessGet = NULL;
	if(!pFnProcessGet)
		pFnProcessGet = UObject::FindFunction("Function IpDrv.WebConnection.ProcessGet");

	IpDrv_ProcessGet_Parms ProcessGet_Parms;
	memcpy(&ProcessGet_Parms.S,&S,0xC);
	ProcessEvent(pFnProcessGet,NULL,&ProcessGet_Parms,NULL);
}

struct IpDrv_GetApplication_Parms
{
	struct FString                                     URI;                                              		// 0x000000 (0x000C)              
	struct FString                                     SubURI;                                           		// 0x00000C (0x000C)              
	class UWebApplication*                             ReturnValue;                                      		// 0x000018 (0x0004)              
	//int                                                I;                                                		// 0x00001C (0x0004)              
	//int                                                L;                                                		// 0x000020 (0x0004)              
};

class UWebApplication* AWebServer::GetApplication(struct FString URI,struct FString* SubURI)
{
	static UFieldFunc* pFnGetApplication = NULL;
	if(!pFnGetApplication)
		pFnGetApplication = UObject::FindFunction("Function IpDrv.WebServer.GetApplication");

	IpDrv_GetApplication_Parms GetApplication_Parms;
	memcpy(&GetApplication_Parms.URI,&URI,0xC);
	ProcessEvent(pFnGetApplication,NULL,&GetApplication_Parms,NULL);
	if(SubURI)
		memcpy(SubURI,&GetApplication_Parms.SubURI,0xC);
	return GetApplication_Parms.ReturnValue;
}

struct IpDrv_GainedChild_Parms
{
	class AActor*                                      C;                                                		// 0x000000 (0x0004)              
};

void AWebServer::GainedChild(class AActor* C)
{
	static UFieldFunc* pFnGainedChild = NULL;
	if(!pFnGainedChild)
		pFnGainedChild = UObject::FindFunction("Function IpDrv.WebServer.GainedChild");

	IpDrv_GainedChild_Parms GainedChild_Parms;
	GainedChild_Parms.C = C;
	ProcessEvent(pFnGainedChild,NULL,&GainedChild_Parms,NULL);
}

struct IpDrv_Destroyed_Parms
{
	//int                                                I;                                                		// 0x000000 (0x0004)              
};

void AWebServer::Destroyed()
{
	static UFieldFunc* pFnDestroyed = NULL;
	if(!pFnDestroyed)
		pFnDestroyed = UObject::FindFunction("Function IpDrv.WebServer.Destroyed");

	IpDrv_Destroyed_Parms Destroyed_Parms;
	ProcessEvent(pFnDestroyed,NULL,&Destroyed_Parms,NULL);
}

struct IpDrv_LostChild_Parms
{
	class AActor*                                      C;                                                		// 0x000000 (0x0004)              
};

void AWebServer::LostChild(class AActor* C)
{
	static UFieldFunc* pFnLostChild = NULL;
	if(!pFnLostChild)
		pFnLostChild = UObject::FindFunction("Function IpDrv.WebServer.LostChild");

	IpDrv_LostChild_Parms LostChild_Parms;
	LostChild_Parms.C = C;
	ProcessEvent(pFnLostChild,NULL,&LostChild_Parms,NULL);
}

struct IpDrv_PostBeginPlay_Parms
{
	//int                                                I;                                                		// 0x000000 (0x0004)              
	//class UClass*                                      ApplicationClass;                                 		// 0x000004 (0x0004)              
	//struct FIpAddr                                     L;                                                		// 0x000008 (0x0014)              
	//struct FString                                     S;                                                		// 0x00001C (0x000C)              
};

void AWebServer::PostBeginPlay()
{
	static UFieldFunc* pFnPostBeginPlay = NULL;
	if(!pFnPostBeginPlay)
		pFnPostBeginPlay = UObject::FindFunction("Function IpDrv.WebServer.PostBeginPlay");

	IpDrv_PostBeginPlay_Parms PostBeginPlay_Parms;
	ProcessEvent(pFnPostBeginPlay,NULL,&PostBeginPlay_Parms,NULL);
}
