
/*
-----------------------------------------------------------------
 - UEnum
-----------------------------------------------------------------
*/
enum ELinkMode
{
	MODE_Text = 0,
	MODE_Line = 1,
	MODE_Binary = 2,
	MODE_MAX = 3,
};
enum ELineMode
{
	LMODE_auto = 0,
	LMODE_DOS = 1,
	LMODE_UNIX = 2,
	LMODE_MAC = 3,
	LMODE_MAX = 4,
};
enum EReceiveMode
{
	RMODE_Manual = 0,
	RMODE_Event = 1,
	RMODE_MAX = 2,
};
enum ELinkState
{
	STATE_Initialized = 0,
	STATE_Ready = 1,
	STATE_Listening = 2,
	STATE_Connecting = 3,
	STATE_Connected = 4,
	STATE_ListenClosePending = 5,
	STATE_ConnectClosePending = 6,
	STATE_ListenClosing = 7,
	STATE_ConnectClosing = 8,
	STATE_MAX = 9,
};
enum ERequestType
{
	Request_GET = 0,
	Request_POST = 1,
	Request_MAX = 2,
};

/*
-----------------------------------------------------------------
 - Classes
-----------------------------------------------------------------
*/
//0x000000 (0x000040 - 0x000040)
//ClientBeaconAddressResolver[0x0E0E89C0]
class UClientBeaconAddressResolver : public UObject
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.ClientBeaconAddressResolver");
		return pClassPointer;
	};
};
UClass* UClientBeaconAddressResolver::pClassPointer = NULL;

//0x000018 (0x000278 - 0x000260)
//InternetLink[0x0E0E8890]
class AInternetLink : public AInfo
{
public:
	unsigned char                                      LinkMode;                                         		// 0x000260 (0x0001)              PROPERTY: ELinkMode
	unsigned char                                      InLineMode;                                       		// 0x000261 (0x0001)              PROPERTY: ELineMode
	unsigned char                                      OutLineMode;                                      		// 0x000262 (0x0001)              PROPERTY: ELineMode
	unsigned char                                      ReceiveMode;                                      		// 0x000263 (0x0001)              PROPERTY: EReceiveMode
	DWORD                                              Socket;                                           		// 0x000264 (0x0004)              
	int                                                Port;                                             		// 0x000268 (0x0004)              
	DWORD                                              RemoteSocket;                                     		// 0x00026C (0x0004)              
	DWORD                                              PrivateResolveInfo;                               		// 0x000270 (0x0004)              
	int                                                DataPending;                                      		// 0x000274 (0x0004)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.InternetLink");
		return pClassPointer;
	};

public:
	bool StringToIpAddr(struct FString str,struct FIpAddr* Addr);//IpDrv.InternetLink.StringToIpAddr
	void ResolveFailed();//IpDrv.InternetLink.ResolveFailed
	void Resolved(struct FIpAddr Addr);//IpDrv.InternetLink.Resolved
	int GetLastError();//IpDrv.InternetLink.GetLastError
	bool IsDataPending();//IpDrv.InternetLink.IsDataPending
	void Resolve(struct FString Domain);//IpDrv.InternetLink.Resolve
	bool ParseURL(struct FString URL,struct FString* Addr,int* PortNum,struct FString* LevelName,struct FString* EntryName);//IpDrv.InternetLink.ParseURL
	struct FString IpAddrToString(struct FIpAddr Arg);//IpDrv.InternetLink.IpAddrToString
	void GetLocalIP(struct FIpAddr* Arg);//IpDrv.InternetLink.GetLocalIP
};
UClass* AInternetLink::pClassPointer = NULL;

//0x000034 (0x0002AC - 0x000278)
//TcpLink[0x0E0E8760]
class ATcpLink : public AInternetLink
{
public:
	unsigned char                                      LinkState;                                        		// 0x000278 (0x0001)              PROPERTY: ELinkState
	unsigned char                                      _0x000279[0x3];                                   		// 0x000279 (0x0003) MISSED OFFSET
	struct FIpAddr                                     RemoteAddr;                                       		// 0x00027C (0x0014)              
	class UClass*                                      AcceptClass;                                      		// 0x000290 (0x0004)              
	TArray<unsigned char>                              SendFIFO;                                         		// 0x000294 (0x000C)              
	struct FString                                     RecvBuf;                                          		// 0x0002A0 (0x000C)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.TcpLink");
		return pClassPointer;
	};

public:
	int ReadBinary(int Count,unsigned char* B);//IpDrv.TcpLink.ReadBinary
	void Closed();//IpDrv.TcpLink.Closed
	bool IsConnected();//IpDrv.TcpLink.IsConnected
	void Accepted();//IpDrv.TcpLink.Accepted
	int SendBinary(int Count,unsigned char* B);//IpDrv.TcpLink.SendBinary
	void Opened();//IpDrv.TcpLink.Opened
	void ReceivedLine(struct FString Line);//IpDrv.TcpLink.ReceivedLine
	int ReadText(struct FString* str);//IpDrv.TcpLink.ReadText
	bool Listen();//IpDrv.TcpLink.Listen
	void ReceivedBinary(int Count,unsigned char* B);//IpDrv.TcpLink.ReceivedBinary
	int SendText(struct FString str);//IpDrv.TcpLink.SendText
	bool Close();//IpDrv.TcpLink.Close
	int BindPort(int PortNum,bool bUseNextAvailable);//IpDrv.TcpLink.BindPort
	bool Open(struct FIpAddr Addr);//IpDrv.TcpLink.Open
	void ReceivedText(struct FString Text);//IpDrv.TcpLink.ReceivedText
};
UClass* ATcpLink::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//MeshBeacon[0x0E0E8630]
class UMeshBeacon : public UObject
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.MeshBeacon");
		return pClassPointer;
	};
};
UClass* UMeshBeacon::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//MeshBeaconClient[0x0E0E8500]
class UMeshBeaconClient : public UMeshBeacon
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.MeshBeaconClient");
		return pClassPointer;
	};
};
UClass* UMeshBeaconClient::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//MeshBeaconHost[0x0E0E83D0]
class UMeshBeaconHost : public UMeshBeacon
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.MeshBeaconHost");
		return pClassPointer;
	};
};
UClass* UMeshBeaconHost::pClassPointer = NULL;

//0x000014 (0x000110 - 0x0000FC)
//OnlineSubsystemCommonImpl[0x0E0E82A0]
class UOnlineSubsystemCommonImpl : public UOnlineSubsystem
{
public:
	DWORD                                              VoiceEngine;                                      		// 0x0000FC (0x0004)              
	int                                                MaxLocalTalkers;                                  		// 0x000100 (0x0004)              
	int                                                MaxRemoteTalkers;                                 		// 0x000104 (0x0004)              
	unsigned long                                      bIsUsingSpeechRecognition : 1;                    		// 0x000108 (0x0004) [0x00000001] 
	class UOnlineGameInterfaceImpl*                    GameInterfaceImpl;                                		// 0x00010C (0x0004)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.OnlineSubsystemCommonImpl");
		return pClassPointer;
	};

public:
	bool IsPlayerInSession(struct FName SessionName,struct FUniqueNetId PlayerID);//IpDrv.OnlineSubsystemCommonImpl.IsPlayerInSession
	struct FString GetPlayerNicknameFromIndex(int UserIndex);//IpDrv.OnlineSubsystemCommonImpl.GetPlayerNicknameFromIndex
	void GetRegisteredPlayers(struct FName SessionName,TArray<struct FUniqueNetId>* OutRegisteredPlayers);//IpDrv.OnlineSubsystemCommonImpl.GetRegisteredPlayers
};
UClass* UOnlineSubsystemCommonImpl::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//PartyBeacon[0x0E0E8170]
class UPartyBeacon : public UObject
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.PartyBeacon");
		return pClassPointer;
	};
};
UClass* UPartyBeacon::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//PartyBeaconClient[0x0E0E8040]
class UPartyBeaconClient : public UPartyBeacon
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.PartyBeaconClient");
		return pClassPointer;
	};
};
UClass* UPartyBeaconClient::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//PartyBeaconHost[0x0E0E7F10]
class UPartyBeaconHost : public UPartyBeacon
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.PartyBeaconHost");
		return pClassPointer;
	};
};
UClass* UPartyBeaconHost::pClassPointer = NULL;

//0x0000BC (0x0000FC - 0x000040)
//WebRequest[0x0E0E7A50]
class UWebRequest : public UObject
{
public:
	struct FString                                     RemoteAddr;                                       		// 0x000040 (0x000C)              
	struct FString                                     URI;                                              		// 0x00004C (0x000C)              
	struct FString                                     UserName;                                         		// 0x000058 (0x000C)              
	struct FString                                     Password;                                         		// 0x000064 (0x000C)              
	int                                                ContentLength;                                    		// 0x000070 (0x0004)              
	struct FString                                     ContentType;                                      		// 0x000074 (0x000C)              
	unsigned char                                      RequestType;                                      		// 0x000080 (0x0001)              PROPERTY: ERequestType
	unsigned char                                      _0x000081[0x3];                                   		// 0x000081 (0x0003) MISSED OFFSET
	struct FMap_Mirror                                 HeaderMap;                                        		// 0x000084 (0x003C)              
	struct FMap_Mirror                                 VariableMap;                                      		// 0x0000C0 (0x003C)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.WebRequest");
		return pClassPointer;
	};

public:
	void ProcessHeaderString(struct FString S);//IpDrv.WebRequest.ProcessHeaderString
	void GetVariables(TArray<struct FString>* varNames);//IpDrv.WebRequest.GetVariables
	struct FString GetVariableNumber(struct FString VariableName,int Number,struct FString DefaultValue);//IpDrv.WebRequest.GetVariableNumber
	int GetHexDigit(struct FString D);//IpDrv.WebRequest.GetHexDigit
	void AddHeader(struct FString HeaderName,struct FString Value);//IpDrv.WebRequest.AddHeader
	void Dump();//IpDrv.WebRequest.Dump
	int GetVariableCount(struct FString VariableName);//IpDrv.WebRequest.GetVariableCount
	void DecodeFormData(struct FString Data);//IpDrv.WebRequest.DecodeFormData
	struct FString GetVariable(struct FString VariableName,struct FString DefaultValue);//IpDrv.WebRequest.GetVariable
	struct FString EncodeBase64(struct FString Decoded);//IpDrv.WebRequest.EncodeBase64
	struct FString GetHeader(struct FString HeaderName,struct FString DefaultValue);//IpDrv.WebRequest.GetHeader
	void GetHeaders(TArray<struct FString>* Headers);//IpDrv.WebRequest.GetHeaders
	void AddVariable(struct FString VariableName,struct FString Value);//IpDrv.WebRequest.AddVariable
	struct FString DecodeBase64(struct FString Encoded);//IpDrv.WebRequest.DecodeBase64
};
UClass* UWebRequest::pClassPointer = NULL;

//0x000068 (0x0000A8 - 0x000040)
//WebResponse[0x0E0E7920]
class UWebResponse : public UObject
{
public:
	TArray<struct FString>                             Headers;                                          		// 0x000040 (0x000C)              
	struct FMap_Mirror                                 ReplacementMap;                                   		// 0x00004C (0x003C)              
	struct FString                                     IncludePath;                                      		// 0x000088 (0x000C)              
	struct FString                                     CharSet;                                          		// 0x000094 (0x000C)              
	class AWebConnection*                              Connection;                                       		// 0x0000A0 (0x0004)              
	unsigned long                                      bSentText : 1;                                    		// 0x0000A4 (0x0004) [0x00000001] 
	unsigned long                                      bSentResponse : 1;                                		// 0x0000A4 (0x0004) [0x00000002] 

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.WebResponse");
		return pClassPointer;
	};

public:
	void ClearSubst();//IpDrv.WebResponse.ClearSubst
	void Redirect(struct FString URL);//IpDrv.WebResponse.Redirect
	bool SendCachedFile(struct FString Filename,struct FString ContentType);//IpDrv.WebResponse.SendCachedFile
	bool SentText();//IpDrv.WebResponse.SentText
	bool IncludeBinaryFile(struct FString Filename);//IpDrv.WebResponse.IncludeBinaryFile
	bool FileExists(struct FString Filename);//IpDrv.WebResponse.FileExists
	bool IncludeUHTM(struct FString Filename);//IpDrv.WebResponse.IncludeUHTM
	struct FString LoadParsedUHTM(struct FString Filename);//IpDrv.WebResponse.LoadParsedUHTM
	void HTTPError(int ErrorNum,struct FString Data);//IpDrv.WebResponse.HTTPError
	void Dump();//IpDrv.WebResponse.Dump
	void HTTPHeader(struct FString Header);//IpDrv.WebResponse.HTTPHeader
	void Subst(struct FString Variable,struct FString Value,bool bClear);//IpDrv.WebResponse.Subst
	void HTTPResponse(struct FString Header);//IpDrv.WebResponse.HTTPResponse
	void AddHeader(struct FString Header,bool bReplace);//IpDrv.WebResponse.AddHeader
	void SendHeaders();//IpDrv.WebResponse.SendHeaders
	void SendStandardHeaders(struct FString ContentType,bool bCache);//IpDrv.WebResponse.SendStandardHeaders
	bool SentResponse();//IpDrv.WebResponse.SentResponse
	void SendBinary(int Count,unsigned char* B);//IpDrv.WebResponse.SendBinary
	struct FString GetHTTPExpiration(int OffsetSeconds);//IpDrv.WebResponse.GetHTTPExpiration
	void SendText(struct FString Text,bool bNoCRLF);//IpDrv.WebResponse.SendText
	void FailAuthentication(struct FString Realm);//IpDrv.WebResponse.FailAuthentication
};
UClass* UWebResponse::pClassPointer = NULL;

//0x000000 (0x000054 - 0x000054)
//HelloWeb[0x24B12D20]
class UHelloWeb : public UWebApplication
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.HelloWeb");
		return pClassPointer;
	};

public:
	void Init();//IpDrv.HelloWeb.Init
	void Query(class UWebRequest* Request,class UWebResponse* Response);//IpDrv.HelloWeb.Query
};
UClass* UHelloWeb::pClassPointer = NULL;

//0x000014 (0x000054 - 0x000040)
//WebApplication[0x24B12BF0]
class UWebApplication : public UObject
{
public:
	class AWorldInfo*                                  WorldInfo;                                        		// 0x000040 (0x0004)              
	class AWebServer*                                  WebServer;                                        		// 0x000044 (0x0004)              
	struct FString                                     Path;                                             		// 0x000048 (0x000C)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.WebApplication");
		return pClassPointer;
	};

public:
	void CleanupApp();//IpDrv.WebApplication.CleanupApp
	bool PreQuery(class UWebRequest* Request,class UWebResponse* Response);//IpDrv.WebApplication.PreQuery
	void Init();//IpDrv.WebApplication.Init
	void Cleanup();//IpDrv.WebApplication.Cleanup
	void PostQuery(class UWebRequest* Request,class UWebResponse* Response);//IpDrv.WebApplication.PostQuery
	void Query(class UWebRequest* Request,class UWebResponse* Response);//IpDrv.WebApplication.Query
};
UClass* UWebApplication::pClassPointer = NULL;

//0x000000 (0x000054 - 0x000054)
//ImageServer[0x24B12AC0]
class UImageServer : public UWebApplication
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.ImageServer");
		return pClassPointer;
	};

public:
	void Query(class UWebRequest* Request,class UWebResponse* Response);//IpDrv.ImageServer.Query
};
UClass* UImageServer::pClassPointer = NULL;

//0x000000 (0x000040 - 0x000040)
//OnlineGameInterfaceImpl[0x24B12990]
class UOnlineGameInterfaceImpl : public UObject
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.OnlineGameInterfaceImpl");
		return pClassPointer;
	};
};
UClass* UOnlineGameInterfaceImpl::pClassPointer = NULL;

//0x000030 (0x0002DC - 0x0002AC)
//WebConnection[0x24B12860]
class AWebConnection : public ATcpLink
{
public:
	class AWebServer*                                  WebServer;                                        		// 0x0002AC (0x0004)              
	struct FString                                     ReceivedData;                                     		// 0x0002B0 (0x000C)              
	class UWebRequest*                                 Request;                                          		// 0x0002BC (0x0004)              
	class UWebResponse*                                Response;                                         		// 0x0002C0 (0x0004)              
	class UWebApplication*                             Application;                                      		// 0x0002C4 (0x0004)              
	unsigned long                                      bDelayCleanup : 1;                                		// 0x0002C8 (0x0004) [0x00000001] 
	int                                                RawBytesExpecting;                                		// 0x0002CC (0x0004)              
	int                                                MaxValueLength;                                   		// 0x0002D0 (0x0004)              
	int                                                MaxLineLength;                                    		// 0x0002D4 (0x0004)              
	int                                                ConnID;                                           		// 0x0002D8 (0x0004)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.WebConnection");
		return pClassPointer;
	};

public:
	void CreateResponseObject();//IpDrv.WebConnection.CreateResponseObject
	void Accepted();//IpDrv.WebConnection.Accepted
	void EndOfHeaders();//IpDrv.WebConnection.EndOfHeaders
	void Timer();//IpDrv.WebConnection.Timer
	void ReceivedText(struct FString Text);//IpDrv.WebConnection.ReceivedText
	void CheckRawBytes();//IpDrv.WebConnection.CheckRawBytes
	void ProcessPost(struct FString S);//IpDrv.WebConnection.ProcessPost
	bool IsHanging();//IpDrv.WebConnection.IsHanging
	void Cleanup();//IpDrv.WebConnection.Cleanup
	void ReceivedLine(struct FString S);//IpDrv.WebConnection.ReceivedLine
	void Closed();//IpDrv.WebConnection.Closed
	void ProcessHead(struct FString S);//IpDrv.WebConnection.ProcessHead
	void ProcessGet(struct FString S);//IpDrv.WebConnection.ProcessGet
};
UClass* AWebConnection::pClassPointer = NULL;

//0x00014C (0x0003F8 - 0x0002AC)
//WebServer[0x24B12730]
class AWebServer : public ATcpLink
{
public:
	struct FString                                     ServerName;                                       		// 0x0002AC (0x000C)              
	struct FString                                     Applications[0xA];                                		// 0x0002B8 (0x0078)              
	struct FString                                     ApplicationPaths[0xA];                            		// 0x000330 (0x0078)              
	unsigned long                                      bEnabled : 1;                                     		// 0x0003A8 (0x0004) [0x00000001] 
	int                                                ListenPort;                                       		// 0x0003AC (0x0004)              
	int                                                MaxConnections;                                   		// 0x0003B0 (0x0004)              
	int                                                DefaultApplication;                               		// 0x0003B4 (0x0004)              
	int                                                ExpirationSeconds;                                		// 0x0003B8 (0x0004)              
	struct FString                                     ServerURL;                                        		// 0x0003BC (0x000C)              
	class UWebApplication*                             ApplicationObjects[0xA];                          		// 0x0003C8 (0x0028)              
	int                                                ConnectionCount;                                  		// 0x0003F0 (0x0004)              
	int                                                ConnID;                                           		// 0x0003F4 (0x0004)              

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.WebServer");
		return pClassPointer;
	};

public:
	class UWebApplication* GetApplication(struct FString URI,struct FString* SubURI);//IpDrv.WebServer.GetApplication
	void GainedChild(class AActor* C);//IpDrv.WebServer.GainedChild
	void Destroyed();//IpDrv.WebServer.Destroyed
	void LostChild(class AActor* C);//IpDrv.WebServer.LostChild
	void PostBeginPlay();//IpDrv.WebServer.PostBeginPlay
};
UClass* AWebServer::pClassPointer = NULL;

//0x00001C (0x009014 - 0x008FF8)
//TcpipConnection[0x0E0E7DE0]
class UTcpipConnection : public UNetConnection
{
public:
	unsigned char                                      _0x008FF8[0x1C];                                  		// 0x008FF8 (0x001C) MISSED OFFSET

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.TcpipConnection");
		return pClassPointer;
	};
};
UClass* UTcpipConnection::pClassPointer = NULL;

//0x000078 (0x0001EC - 0x000174)
//TcpNetDriver[0x0E0E7CB0]
class UTcpNetDriver : public UNetDriver
{
public:
	unsigned char                                      _0x000174[0x78];                                  		// 0x000174 (0x0078) MISSED OFFSET

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.TcpNetDriver");
		return pClassPointer;
	};
};
UClass* UTcpNetDriver::pClassPointer = NULL;

//0x000000 (0x0001EC - 0x0001EC)
//ServerNetDriver[0x0E0E7B80]
class UServerNetDriver : public UTcpNetDriver
{
public:

private:
	static UClass* pClassPointer;

public:
	static UClass* StaticClass()
	{
		if (!pClassPointer)
			pClassPointer = UObject::FindClass("Class IpDrv.ServerNetDriver");
		return pClassPointer;
	};
};
UClass* UServerNetDriver::pClassPointer = NULL;

#ifdef _MSC_VER
	#pragma pack(pop)
#endif